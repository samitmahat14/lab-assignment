
max = 0
for i in range(3):
    number = int(input("Enter number"))
    if i == 0:
        max = number

    if number > max:
        max = number