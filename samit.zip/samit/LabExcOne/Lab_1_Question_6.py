mass = float(input("Enter your weight in Kg"))
height = float(input("Enter your height in m"))

bmi = mass / height ** 2

print(bmi)