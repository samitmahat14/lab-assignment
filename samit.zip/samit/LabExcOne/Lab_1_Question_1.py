
def sum(one, two, three):
    return one + two + three

one = int(input("first number"))
two = int(input("second number"))
three = int(input("third number"))

print(sum(one, two, three))

