lengthOfBase = int(input("Enter base length"))
height = int(input("Enter height length"))
def area(length, height):
    return (length * height) / 2

print(area(lengthOfBase, height))