a = 2
b = 3
c = 4
d = 3

print(a == b)
print(a != d)
print(b == d)
print(a != c)
