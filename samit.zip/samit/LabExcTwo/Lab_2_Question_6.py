number = int(input("Enter an integer"))

def lastDigit(number):
    return number % 10

print(lastDigit(number))