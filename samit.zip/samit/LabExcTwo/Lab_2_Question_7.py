number = float(input("enter a positive real number"))

integralPart = int(number)
fractionalPart = number - integralPart

print(fractionalPart)