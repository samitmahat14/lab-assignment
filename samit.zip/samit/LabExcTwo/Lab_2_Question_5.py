number = int(input("Enter a number"))

if number > 0:
    print("True")
elif number < 0:
    print("False")
else:
    print("zero")