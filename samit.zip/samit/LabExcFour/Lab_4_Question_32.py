set1 = {1, 2, 3}
set2 = {3, 4, 5}

intersection = set1.intersection(set2)

print(intersection)

