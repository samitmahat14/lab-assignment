tup = ('A', 1, 2, 2.0)
print(tup)