dict =	{
  "1": 1,
  "2": 2,
  "3": 3
}
dict["4"] = 4

print(dict)