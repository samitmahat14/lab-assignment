items = [1,3,4,55,1,22,77]

del(items[0])

print(items)

del(items[3])

print(items)

del(items[3])

print(items)