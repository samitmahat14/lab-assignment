set = {1, 2, 3}

set.add(4)

print(set)