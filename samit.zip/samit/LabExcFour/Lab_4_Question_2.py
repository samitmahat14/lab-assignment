def toCelsius(f):
    return (5/9) * (f - 32)

def toFahrenheit(c):
    return (9/5 * c) + 32


print(toCelsius(98))
print(toFahrenheit(37))