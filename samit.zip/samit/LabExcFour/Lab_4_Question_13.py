items = [1,3,4,55,1,22]

max = 0

for i in range(len(items)):
    if items[i] > max:
        max = items[i]

print(max)