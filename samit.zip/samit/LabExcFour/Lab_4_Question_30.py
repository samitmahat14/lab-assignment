set = {1, 2, 3}
set.add(4)
set.remove(2)
print(set)