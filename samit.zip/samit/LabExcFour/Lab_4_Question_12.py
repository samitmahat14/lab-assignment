items = [1,3,4,55,1,22]
multiply = 1
for item in items:
    multiply *= item

print(multiply)