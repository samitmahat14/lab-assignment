emptyList = [1]

if len(emptyList) <= 0:
    print("list empty")
else:
    print("list isn't empty")