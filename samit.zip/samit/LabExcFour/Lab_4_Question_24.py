tup = ('Softwarica','Dilibazar','27A')
dummyString = ''.join(tup)
print(dummyString)