tup = ('Softwarica','Dilibazar','27A')

(college, address, batch) = tup

print(college)
print(address)
print(batch)