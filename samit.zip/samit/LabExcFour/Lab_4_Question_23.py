a = ('Softwarica','Dilibazar','27A')
b = a + tuple("Z")
print(b)