tup = (1,2,1,33,44)
print(tup[2])