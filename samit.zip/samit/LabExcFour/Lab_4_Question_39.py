dict1 = {
    "1": 1,
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6
}
sum = 0
values = dict1.values()
for item in values:
    sum += item
print(sum)