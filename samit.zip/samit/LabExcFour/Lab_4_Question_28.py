set = {'nepal', 'china', 'finland'}

for item in set:
    print(item)