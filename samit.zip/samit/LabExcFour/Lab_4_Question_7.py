numbers = []
for i in range(7):
    numbers.append(i)

for item in numbers:
    if item % 3 != 0:
        print(item)
