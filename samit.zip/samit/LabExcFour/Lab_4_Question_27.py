set = {'nepal', 'china', 'finland'}
print(set)