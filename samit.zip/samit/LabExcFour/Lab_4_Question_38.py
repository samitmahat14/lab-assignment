dict1 =	{
  "1": 1,
  "2": 2,
  "3": 3
}

dict2 =	{
  "4": 4,
  "5": 5,
  "6": 6
}

dict4 = dict(dict1)
dict4.update(dict2)
print(dict4)