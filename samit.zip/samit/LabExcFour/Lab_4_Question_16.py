items = [1,3,4,55,1,22]

newItems = items.copy()
print(newItems)