items = [1,3,4,55,1,22]
sum = 0
for item in items:
    sum += item

print(sum)