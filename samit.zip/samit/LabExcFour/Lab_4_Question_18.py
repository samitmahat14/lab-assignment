from random import randint

items = [1,3,4,55,1,22]

value = randint(0, len(items) - 1)
print(value)
